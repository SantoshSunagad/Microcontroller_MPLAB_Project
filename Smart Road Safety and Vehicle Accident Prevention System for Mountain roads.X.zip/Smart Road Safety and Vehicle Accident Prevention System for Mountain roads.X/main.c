/*
 Name : SANTOSH RAMESH SUNAGAD
 DATE : 15/03/24
 Description : Smart Road Safety and Vehicle Accident Prevention System for Mountain Road's 
 */

#include <xc.h>
#include "clcd.h"
#include "config.h"
#include "PIN_MACROS.h"

static int init_config(void) {
    init_clcd();
    TRISB = 0xE0;   //Setting the Direction's of PORTB 
    BUZZER=OFF;
    clcd_print(" Acident Prevnt", LINE1(0));
    clcd_print("Mountain Roads", LINE2(0));
    for(unsigned long int i=400000;i--;);
    CLEAR_DISP_SCREEN;
}

unsigned char Road[][30] = {"STOP HERE    ", "GO AHEAD      "};

void main(void) {
    init_config();
    
    unsigned int index = 1;
    while (1) {
        if (SENSOR1) {
            if (ROAD1_GREEN != ON) {
                index = 0;
                BUZZER=ON;
                ROAD1_RED = OFF;
                ROAD1_GREEN = ON;
                ROAD2_RED = ON;
                ROAD2_GREEN = OFF;
            }
        } else if (SENSOR2) {
            if (ROAD2_GREEN != ON) {
                index = 0;
                BUZZER=ON;
                ROAD2_RED = OFF;
                ROAD2_GREEN = ON;
                ROAD1_RED = ON;
                ROAD1_GREEN = OFF; 
            }
        } else {
            index = 1;
            BUZZER=OFF;
            ROAD1_RED = ON;
            ROAD2_RED = ON;
            ROAD1_GREEN = OFF;
            ROAD2_GREEN = OFF;
        }
        clcd_print(Road[index], LINE1(4));
    }
}
