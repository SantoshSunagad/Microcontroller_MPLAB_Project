/* 
 * File:   PIN_MACROS.h
 * Author: windows 10
 *
 * Created on March 14, 2024, 1:19 PM
 */

#ifndef PIN_MACROS_H
#define	PIN_MACROS_H

#define SENSOR1 PORTBbits.RB6
#define SENSOR2 PORTBbits.RB7
#define ROAD1_RED RB0
#define ROAD1_GREEN RB1
#define ROAD2_RED RB2
#define ROAD2_GREEN RB3
#define BUZZER PORTBbits.RB4

#define ON 1
#define OFF 0

#endif	/* PIN_MACROS_H */

