/* 
 * File:   main.h
 * Author: windows 10
 *
 * Created on March 10, 2024, 3:39 PM
 */

#ifndef MAIN_H
#define	MAIN_H

/*ROAD 1*/
#define R1RED   PORTAbits.RA0
#define R1YELLOW    PORTAbits.RA1
#define R1GRN   PORTAbits.RA2

/*ROAD 2*/
#define R2RED   PORTAbits.RA3
#define R2YELLOW    PORTAbits.RA4
#define R2GRN   PORTAbits.RA5

/*ROAD 3*/
#define R3RED   RB2
#define R3YELLOW    RB3
#define R3GRN   RB4

/*ROAD 4*/
#define R4RED   RB5
#define R4YELLOW    RB6
#define R4GRN   RB7

#endif	/* MAIN_H */

