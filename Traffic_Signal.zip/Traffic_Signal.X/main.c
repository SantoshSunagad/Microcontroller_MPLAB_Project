/* NAME : SANTOSH
 DATE : 11/03/24
 Description : Traffic Signal (4-ROAD) 
 * LEVEL : Easy
 */
/*-----------------------------------------------------------------------------*/
#include <xc.h>
#include "main.h"
#include "timer0.h"
#include "clcd.h"

static void init_config(void) {
    //Write your initialization code here
    init_timer0();
    init_clcd();
    TRISB = 0x00;
    TRISA = 0x00;
    PORTB = 0x00;
    PORTA = 0x00;
    GIE = 1;
    PEIE = 1;
    PORTB = 0X09;
}
unsigned int second = 15;
char road[][20] = {"ROAD 1", "ROAD 2", "ROAD 3", "ROAD 4"};

void main(void) {
    init_config(); //Calling initializing function
    unsigned int ROAD = 0;
    while (1) {

        if (second == 0) {
            second = 15;
            if (++ROAD == 4)
                ROAD = 0;
        }
        /* CLCD DISPLAY */
        clcd_putch((second / 10) + '0', LINE2(14));
        clcd_putch((second % 10) + '0', LINE2(15));
        clcd_print(road[ROAD], LINE1(5));
        /*ROAD's */
        if (ROAD == 0) {
            if (second >= 7) {
                PORTA = (PORTA & 0X00) | 0x0C;
            }
            if (second <= 3) {
                PORTA = (PORTA & 0X00) | 0x0A;
            }
            if (second <= 0) {
                PORTA = (PORTA & 0X00) | 0x09;
            }
        } else if (ROAD == 1) {
            if (second >= 7) {
                PORTA = (PORTA & 0x00) | 0x21;
            }
            if (second <= 3) {
                PORTA = (PORTA & 0x00) | 0x11;
            }
            if (second <= 0) {
                PORTA = (PORTA & 0x00) | 0x09;
            }
        } else if (ROAD == 2) {
            if (second >= 7) {
                PORTB = (PORTB & 0x00) | 0x0C;
            }
            if (second <= 3) {
                PORTB = (PORTB & 0x00) | 0x0A;
            }
            if (second <= 0) {
                PORTB = (PORTB & 0x00) | 0x09;
            }
        } else if (ROAD == 3) {
            if (second >= 7) {
                PORTB = (PORTB & 0x00) | 0x21;
            }
            if (second <= 3) {
                PORTB = (PORTB & 0x00) | 0x11;
            }
            if (second <= 0) {
                PORTB = (PORTB & 0x00) | 0x09;
            }
        }
    }

}
