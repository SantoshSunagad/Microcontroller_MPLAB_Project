/* 
 * File:   main.h
 * Author: windows 10
 *
 * Created on March 16, 2024, 9:34 AM
 */

#ifndef MAIN_H
#define	MAIN_H

#include "clcd.h"
#include "uart.h"
#include "adc.h"
#include <string.h>


/* FAN -> PORTE */
#define H_FAN RE0
#define B_FAN RE1
#define GATE_MTR RE2
#define WATER_PUMP RB6

/* MAIN LED LIGHT's */
#define H_M_LGT RC2
#define B_M_LGT RC3
#define K_M_LGT RC4

/* BED LAMPS */
#define H_LAMP RB4
#define B_LAMP RB5

/* SENSORS */
#define PIR_H RB0
#define PIR_B RB1
#define IR_SNS RB2
#define GAS_SNS RB3

/* ADC CHANNEL */
#define ANG_TEMP RA0
#define ANG_LDR  RA1


#define ON 1
#define OFF 0
//#define
//#define
//#define
//#define
//#define
//#define

#endif	/* MAIN_H */

