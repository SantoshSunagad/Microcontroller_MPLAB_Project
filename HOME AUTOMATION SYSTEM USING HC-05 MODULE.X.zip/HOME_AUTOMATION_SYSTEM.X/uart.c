#include <xc.h>
#include "config.h"
#include "clcd.h"
#include <string.h>

extern unsigned char y[4];
extern unsigned int i;

void __interrupt() RECIVE() {
    if (PIR1bits.RCIF == 1) { 
        y[i] = RCREG;
        ++i;
        if(strcmp(RCREG, ' ') == 0)
        {
            i=0;
        }
        PIR1bits.RCIF = 0;
    }
}

void init_uart() {
    INTCONbits.GIE = 1;
    INTCONbits.PEIE = 1;
    PIE1bits.RCIE = 1;

    TXSTA = 0x24;
    RCSTA = 0x90;
    //Baud rate 9600
    SPBRG = 129;

    TRISC7 = 1;
    TRISC6 = 0;
}

void putch(unsigned char byte) {
    /* Output one byte */
    /* Set when register is empty */
    while (!TXIF) {
        continue;
    }
    TXREG = byte;
}

void puts(const char *s) {
    while (*s) {
        putch(*s++);
    }
}