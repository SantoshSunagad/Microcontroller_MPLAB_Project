/* 
 * File:   uart.h
 * Author: windows 10
 *
 * Created on March 15, 2024, 10:26 AM
 */

#ifndef UART_H
#define	UART_H


#define __XTAL_FREQ 20000000
unsigned char y[4];

unsigned int i = 0;

void putch(unsigned char byte) ;
void puts(const char *s);
void init_uart();

#endif	/* UART_H */

