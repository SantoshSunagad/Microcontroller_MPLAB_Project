/*
 NAME : SANTOSH RAMESH SUNAGD
 DATE : 14/03/2024
 Description : HOME AUTOMATION SYSTEM USING BLUETOOTH HC05 MODULE 
 */
///////////////////////////////////////////////////////////////////////////////

#include <xc.h>
#include "main.h"


static int init_config(void) {
    init_clcd();
    init_uart();
    init_adc();
    /* SET THE DIRECTIONS */
    TRISA = (TRISA | 0x03);
    TRISB = (TRISB & 0x0F);
    TRISC = (TRISC & 0xE3);
    TRISD = 0x00;
    TRISE = 0x00;
    
    puts("        BLUETOOTH PAIRED SUCCESSFULLY      \n\r");
    clcd_print(" HOME AUTOMATION ", LINE1(0));
    clcd_print("USING HC-05", LINE2(2));
    for (unsigned long int i = 0xFFFA; i--;);
    CLEAR_DISP_SCREEN;
}


void main(void) {
    init_config();
    unsigned int TEMP, LDR, STATUS = 1, MP = 1;
    puts("\n\r              SWITCH KEY's        \n\r");
    puts("\n\nHM -> M_LED\n\rHF -> ON FAN\n\rH1 -> OFF FAN\n\rHL -> LAMP \n\rBM -> B_LED\n\rBF -> ON FAN\n\rB1 -> OFF FAN\n\rBL -> B_LAMP\n\rKM -> KITCHEN LED\n\rWS -> WATWATER PUMP ON\n\rW1 -> WATWATER PUMP OFF\n\rMP -> MAIN POWER SUPPLY\n\rSS -> STATUS\n\r");
    while (1) {
        TEMP = (read_adc(CHANNEL0) / 2) - 1;
        LDR = (read_adc(CHANNEL1) / 10.25);
        /* MAIN SUPPLY SWITCH */
        if (i >= 2 && (strcmp(y, "MP") == 0)) {
            i = 0;
            MP = !MP;
            (MP) ? (puts("\n\rMAIN POER SUPPLY IS ON\n\r")) : (puts("\n\rMAIN POER SUPPLY IS OFF\n\r"));
        }
        /* MAIN SWITCH SUPPLY ON */
        if (MP) {
            if (i >= 2) {
                puts("\n\r");
                /* HALL */
                if (strcmp(y, "HM") == 0) {
                    H_M_LGT = !H_M_LGT;
                    (H_M_LGT) ? (puts("HALL LIGHT IS ON\n\r")) : (puts("HALL LIGHT IS OFF\n\r"));
                }
                if ((strcmp(y, "HF") == 0)) {
                    H_FAN = ON;
                    (!H_FAN) ? (puts("HALL FAN IS ON\n\r")) : (puts("HALL FAN IS OFF\n\r"));

                }
                /* OFF FAN */
                if (strcmp(y, "H1") == 0) {
                    H_FAN = OFF;
                    (H_FAN == OFF) ? (puts("HALL FAN IS OFF\n\r")) : (puts("HALL FAN IS ON\n\r"));

                }
                if (strcmp(y, "HL") == 0) {
                    H_LAMP = !H_LAMP;
                    (H_LAMP) ? (puts("HALL LAMP IS ON\n\r")) : (puts("HALL LAMP IS OFF\n\r"));
                }

                /* BED ROOM */
                if (strcmp(y, "BM") == 0) {
                    B_M_LGT = !B_M_LGT;
                    (B_M_LGT) ? (puts("BED-ROOM LIGHT IS ON\n\r")) : (puts("BED-ROOM LIGHT IS OFF\n\r"));
                }
                if (strcmp(y, "BF") == 0) {
                    B_FAN = ON;
                    (!B_FAN) ? (puts("BED-ROOM FAN IS ON\n\r")) : (puts("BED-ROOM FAN IS OFF\n\r"));
                }
                /* OFF FAN */
                if (strcmp(y, "B1") == 0) {
                    B_FAN = OFF;
                    (B_FAN) ? (puts("BED-ROOM FAN IS ON\n\r")) : (puts("BED-ROOM FAN IS OFF\n\r"));
                }
                if (strcmp(y, "BL") == 0) {
                    B_LAMP = !B_LAMP;
                    (B_LAMP) ? (puts("BED-ROOM LAMP IS ON\n\r")) : (puts("BED-ROOM LAMP IS OFF\n\r"));
                }

                /* KITCHEN */
                /* BLUE TOOTH CONTROLL*/
                if (strcmp(y, "KM") == 0) {
                    K_M_LGT = !K_M_LGT;
                    (K_M_LGT) ? (puts("KITCHEN LIGHT IS ON\n\r")) : (puts("KITCHEN LIGHT IS OFF\n\r"));
                }
                if (strcmp(y, "WS") == 0) {
                    WATER_PUMP = ON;
                    (WATER_PUMP) ? (puts("WATER PUMP IS ON\n\r")) : (puts("WATER PUMP IS OFF\n\r"));
                }
                if (strcmp(y, "W1") == 0) {
                    WATER_PUMP = OFF;
                    (WATER_PUMP) ? (puts("WATER PUMP IS ON\n\r")) : (puts("WATER PUMP IS OFF\n\r"));
                }
                if (strcmp(y, "SS") == 0) {
                    STATUS = 1;
                }
                i=0;
            }
        }/* MAIN SWITCH SUPPLY ON */
        else if (!MP) {
            puts("\n\r MAIN POER SUPPLY OFF\n\rPLEASE RESET ME\n\r");
            H_FAN = OFF;
            H_LAMP = OFF;
            H_M_LGT = OFF;
            B_M_LGT = OFF;
            B_FAN = OFF;
            B_LAMP = OFF;
            K_M_LGT = OFF;
            SLEEP();
        }
        clcd_putch(i + '0', LINE2(14));
        clcd_print("TEMP:", LINE1(2));
        clcd_print("LDR:", LINE2(2));

        clcd_putch((TEMP / 10) + '0', LINE1(8));
        clcd_putch((TEMP % 10) + '0', LINE1(9));
        clcd_putch((LDR / 10) + '0', LINE2(8));
        clcd_putch((LDR % 10) + '0', LINE2(9));
        /* PIR SENSOR*/
        if (LDR <= 66) {
            if (PIR_H == 1) {
                PIR_H = OFF;
                H_M_LGT = ON;
                if (PIR_B == 1) {
                    PIR_B = OFF;
                    B_M_LGT = ON;
                }
            }
        }
        /* EMERGENCY SITUATIONS */
        if (TEMP >= 35 || GAS_SNS) {
            if ((strcmp(y, "ST") == 0) || TEMP <= 35) {
                GAS_SNS = OFF;
            }
            puts("\n\n\rALERT !!!!!\n\r");
            if (GAS_SNS) {
                puts("GAS DETECTED\n\r");
            } else {
                puts("GAS NOT DETECTED\n\r");
            }
            puts("Temprature : ");
            putch('0' + (TEMP / 10));
            putch('0' + (TEMP % 10));
            putch('\n');
        }
        /* GATE CONTROL*/
        if (IR_SNS) {
            CLEAR_DISP_SCREEN;
            clcd_print(" GATE OPENING....", LINE1(0));
            GATE_MTR = ON;
            for (unsigned long int i = 300000; i--;);
            CLEAR_DISP_SCREEN;
            clcd_print(" GATE CLOSED...", LINE1(0));
            GATE_MTR = OFF;
            for (unsigned long int i = 200000; i--;);
            CLEAR_DISP_SCREEN;
        }

        /* TO CHECK ALL HOME APPLIANCES STATUS */
        if (STATUS) {
            STATUS = 0;
            puts("\n          STATUS OF ALL HOME APPLIANCES     \n\n\r");
            (MP) ? (puts("\n\r MAIN POER SUPPLY IS ON\n\r\n\r")) : (puts("\n\r MAIN POER SUPPLY IS OFF\n\r\n\r"));
            (H_M_LGT) ? (puts("HALL LIGHT IS ON\n\r")) : (puts("HALL LIGHT IS OFF\n\r"));
            (H_FAN) ? (puts("HALL FAN IS ON\n\r")) : (puts("HALL FAN IS OFF\n\r"));
            (H_LAMP) ? (puts("HALL LAMP IS ON\n\r")) : (puts("HALL LAMP IS OFF\n\r"));
            (B_M_LGT) ? (puts("BED-ROOM LIGHT IS ON\n\r")) : (puts("BED-ROOM LIGHT IS OFF\n\r"));
            (B_FAN) ? (puts("BED-ROOM FAN IS ON\n\r")) : (puts("BED-ROOM FAN IS OFF\n\r"));
            (B_LAMP) ? (puts("BED-ROOM LAMP IS ON\n\r")) : (puts("BED-ROOM LAMP IS OFF\n\r"));
            (K_M_LGT) ? (puts("KITCHEN LIGHT IS ON\n\r")) : (puts("KITCHEN LIGHT IS OFF\n\r"));
            puts("\n\r                        ALERT !!!!!        \n\r");
            if (GAS_SNS) {
                puts("GAS DETECTED\n\r");
            } else {
                puts("GAS NOT DETECTED\n\r");
            }
            puts("Temprature : ");
            putch('0' + (TEMP / 10));
            putch('0' + (TEMP % 10));
            if (LDR >= 66) {
                puts("\n\n\rHEY, IT's DAY TIME\n\r");
            } else {
                puts("\n\n\rHEY, IT's NIGHT\n\r");
            }
        }
    }
}

